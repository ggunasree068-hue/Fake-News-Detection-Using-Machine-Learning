import streamlit as st
import joblib
import re

# ======================================
# Load model and vectorizer
# ======================================
model = joblib.load("models/fake_news_model_optimized.pkl")
vectorizer = joblib.load("models/tfidf_vectorizer.pkl")

# ======================================
# Trusted news sources
# ======================================
TRUSTED_SOURCES = [
    "cnn",
    "bbc",
    "reuters",
    "associated press",
    "ap",
    "the hindu",
    "ndtv"
]

# ======================================
# Text cleaning function
# ======================================
def clean_text(text):
    text = text.lower()
    text = re.sub(r"http\S+", "", text)
    text = re.sub(r"[^a-z\s]", "", text)
    return text

# ======================================
# Source credibility bonus
# ======================================
def get_source_bonus(source):
    if source.lower().strip() in TRUSTED_SOURCES:
        return 40
    return 0

# ======================================
# Streamlit UI
# ======================================
st.set_page_config(page_title="Fake News Detection", layout="centered")

st.title("📰 Fake News Detection & Media Integrity Analytics")

st.write(
    "This system analyzes political news using **Machine Learning + Media Integrity Analytics**. "
    "It combines **content-based prediction** with **source credibility awareness**."
)

# User inputs
news_text = st.text_area(
    "Enter Full News Text",
    height=200,
    placeholder="Paste the complete news article here for better accuracy..."
)

source = st.text_input(
    "News Source (optional)",
    placeholder="Example: CNN, BBC, Reuters"
)

# ======================================
# Prediction
# ======================================
if st.button("Analyze News"):
    if news_text.strip() == "":
        st.warning("Please enter news text.")
    else:
        # Clean and vectorize text
        cleaned_text = clean_text(news_text)
        vectorized_text = vectorizer.transform([cleaned_text])

        # ML prediction
        prediction = model.predict(vectorized_text)[0]

        # Base integrity score
        base_score = 100 if prediction == 0 else 0

        # Source bonus
        bonus = get_source_bonus(source) if source else 0

        # Final integrity score
        final_score = min(100, max(0, base_score + bonus))

        # Reliability category
        if final_score >= 80:
            category = "Highly Reliable"
        elif final_score >= 50:
            category = "Moderately Reliable"
        else:
            category = "Unreliable"

        # ======================================
        # Display results
        # ======================================
        st.subheader("🔍 Analysis Result")

        if prediction == 0:
            st.success("🟢 Content-based Prediction: REAL")
        else:
            st.error("🔴 Content-based Prediction: FAKE")

        st.metric("Final Integrity Score", final_score)

        if source:
            st.caption(f"Source credibility bonus applied: +{bonus}")

        st.info(f"Reliability Category: **{category}**")

        st.markdown(
            "_Note: This system is a **decision-support tool**. "
            "Predictions are based on linguistic patterns and source credibility, "
            "not real-time fact verification._"
        )
