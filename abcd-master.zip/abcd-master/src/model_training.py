import joblib
from sklearn.linear_model import LogisticRegression
from sklearn.naive_bayes import MultinomialNB
from sklearn.svm import LinearSVC
from sklearn.metrics import accuracy_score, classification_report

# ===============================
# Load TF-IDF data
# ===============================
X_train = joblib.load("models/X_train.pkl")
X_test = joblib.load("models/X_test.pkl")
y_train = joblib.load("models/y_train.pkl")
y_test = joblib.load("models/y_test.pkl")

# ===============================
# Model 1: Logistic Regression
# ===============================
print("\nTraining Logistic Regression...")
lr_model = LogisticRegression(max_iter=1000)
lr_model.fit(X_train, y_train)

lr_preds = lr_model.predict(X_test)
lr_acc = accuracy_score(y_test, lr_preds)

print("Logistic Regression Accuracy:", lr_acc)
print(classification_report(y_test, lr_preds))

# ===============================
# Model 2: Naive Bayes
# ===============================
print("\nTraining Naive Bayes...")
nb_model = MultinomialNB()
nb_model.fit(X_train, y_train)

nb_preds = nb_model.predict(X_test)
nb_acc = accuracy_score(y_test, nb_preds)

print("Naive Bayes Accuracy:", nb_acc)
print(classification_report(y_test, nb_preds))

# ===============================
# Model 3: Support Vector Machine
# ===============================
print("\nTraining SVM...")
svm_model = LinearSVC()
svm_model.fit(X_train, y_train)

svm_preds = svm_model.predict(X_test)
svm_acc = accuracy_score(y_test, svm_preds)

print("SVM Accuracy:", svm_acc)
print(classification_report(y_test, svm_preds))

# ===============================
# Save best model (initially SVM)
# ===============================
joblib.dump(svm_model, "models/fake_news_model.pkl")
print("\nBest model (SVM) saved successfully!")
