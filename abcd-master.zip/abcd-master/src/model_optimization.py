import joblib
from sklearn.svm import LinearSVC
from sklearn.model_selection import GridSearchCV
from sklearn.metrics import classification_report

# ===============================
# Load TF-IDF data
# ===============================
X_train = joblib.load("models/X_train.pkl")
X_test = joblib.load("models/X_test.pkl")
y_train = joblib.load("models/y_train.pkl")
y_test = joblib.load("models/y_test.pkl")

# ===============================
# Define model & hyperparameters
# ===============================
svm = LinearSVC()

param_grid = {
    "C": [0.1, 0.5, 1, 2],
    "loss": ["hinge", "squared_hinge"]
}

# ===============================
# Grid Search
# ===============================
grid = GridSearchCV(
    svm,
    param_grid,
    cv=5,
    scoring="f1",
    n_jobs=-1
)

print("Running GridSearchCV...")
grid.fit(X_train, y_train)

# ===============================
# Best model
# ===============================
best_model = grid.best_estimator_

print("\nBest Parameters:", grid.best_params_)

# ===============================
# Evaluate optimized model
# ===============================
y_pred = best_model.predict(X_test)

print("\nOptimized Model Classification Report:")
print(classification_report(y_test, y_pred))

# ===============================
# Save optimized model
# ===============================
joblib.dump(best_model, "models/fake_news_model_optimized.pkl")
print("\nOptimized model saved successfully!")
