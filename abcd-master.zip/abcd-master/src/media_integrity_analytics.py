import pandas as pd
import joblib
from pathlib import Path

# ===============================
# Load cleaned dataset
# ===============================
BASE_DIR = Path(__file__).resolve().parent.parent
DATA_PATH = BASE_DIR / "data" / "processed" / "cleaned_data.csv"

df = pd.read_csv(DATA_PATH)

# ===============================
# STRONG Defensive Cleaning
# ===============================
# Drop NaNs FIRST
df = df.dropna(subset=["clean_text"])

# Convert to string AFTER dropping NaNs
df["clean_text"] = df["clean_text"].astype(str)

# Strip whitespace
df["clean_text"] = df["clean_text"].str.strip()

# Remove empty and 'nan' strings
df = df[df["clean_text"] != ""]
df = df[df["clean_text"].str.lower() != "nan"]

print("Rows after cleaning:", df.shape[0])
print("Remaining NaNs:", df["clean_text"].isna().sum())

# ===============================
# Load optimized model & vectorizer
# ===============================
model = joblib.load(BASE_DIR / "models" / "fake_news_model_optimized.pkl")
vectorizer = joblib.load(BASE_DIR / "models" / "tfidf_vectorizer.pkl")

# ===============================
# Generate predictions
# ===============================
X = vectorizer.transform(df["clean_text"])
df["prediction"] = model.predict(X)

# ===============================
# Media Integrity Score
# ===============================
# 1 = Fake, 0 = Real
df["integrity_score"] = df["prediction"].apply(lambda x: 100 if x == 0 else 0)

# ===============================
# Reliability Category
# ===============================
def categorize(score):
    if score >= 80:
        return "Highly Reliable"
    elif score >= 50:
        return "Moderately Reliable"
    else:
        return "Unreliable"

df["reliability_category"] = df["integrity_score"].apply(categorize)

# ===============================
# Analytics Summary
# ===============================
summary = df["reliability_category"].value_counts()

print("\nMedia Integrity Summary:")
print(summary)

# ===============================
# Save analytics output
# ===============================
OUTPUT_PATH = BASE_DIR / "data" / "processed" / "media_integrity_analysis.csv"
df.to_csv(OUTPUT_PATH, index=False)

print("\nMedia integrity analytics saved to:", OUTPUT_PATH)
