import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from wordcloud import WordCloud

# ===============================
# Load dataset safely
# ===============================
DATA_PATH = "data/processed/cleaned_data.csv"
df = pd.read_csv(DATA_PATH)

# Force clean_text to string & remove bad rows
df['clean_text'] = df['clean_text'].astype(str)
df['clean_text'] = df['clean_text'].str.strip()
df = df[df['clean_text'] != ""]
df = df[df['clean_text'].str.lower() != "nan"]

print("Dataset shape after cleaning:", df.shape)

# ===============================
# 1. Fake vs Real Distribution
# ===============================
plt.figure()
sns.countplot(x='label', data=df)
plt.title("Fake vs Real News Distribution")
plt.xlabel("Label (0 = Real, 1 = Fake)")
plt.ylabel("Count")
plt.show()

# ===============================
# 2. Text Length Analysis
# ===============================
df['text_length'] = df['clean_text'].apply(lambda x: len(x.split()))

plt.figure()
sns.histplot(
    data=df,
    x='text_length',
    hue='label',
    bins=50,
    kde=True
)
plt.title("Text Length Distribution by Class")
plt.xlabel("Number of Words")
plt.ylabel("Frequency")
plt.show()

# ===============================
# 3. WordCloud - Real News
# ===============================
real_text = " ".join(df[df['label'] == 0]['clean_text'])

real_wc = WordCloud(
    width=800,
    height=400,
    background_color='white'
).generate(real_text)

plt.figure(figsize=(10, 5))
plt.imshow(real_wc)
plt.axis('off')
plt.title("WordCloud - Real News")
plt.show()

# ===============================
# 4. WordCloud - Fake News
# ===============================
fake_text = " ".join(df[df['label'] == 1]['clean_text'])

fake_wc = WordCloud(
    width=800,
    height=400,
    background_color='white'
).generate(fake_text)

plt.figure(figsize=(10, 5))
plt.imshow(fake_wc)
plt.axis('off')
plt.title("WordCloud - Fake News")
plt.show()

print("EDA completed successfully without errors.")
