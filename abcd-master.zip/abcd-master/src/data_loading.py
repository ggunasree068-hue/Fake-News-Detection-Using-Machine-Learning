import pandas as pd

# Load dataset
DATA_PATH = "data/raw/WELFake_Dataset.csv"
df = pd.read_csv(DATA_PATH)

print("="*50)
print("DATASET BASIC INFORMATION")
print("="*50)

print("Shape (rows, columns):", df.shape)
print("\nColumn Names:")
print(df.columns.tolist())

print("\nFirst 5 Rows:")
print(df.head())

print("\nMissing Values Per Column:")
print(df.isnull().sum())

print("\nLabel Distribution:")
print(df['label'].value_counts())
