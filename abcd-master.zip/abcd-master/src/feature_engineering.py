import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split
import joblib
from pathlib import Path

# ===============================
# Load cleaned dataset safely
# ===============================
BASE_DIR = Path(__file__).resolve().parent.parent
DATA_PATH = BASE_DIR / "data" / "processed" / "cleaned_data.csv"

df = pd.read_csv(DATA_PATH)

# ===============================
# PROPER Defensive Cleaning
# ===============================
# Drop rows where clean_text or label is missing
df = df.dropna(subset=["clean_text", "label"])

# Convert to string AFTER dropping NaNs
df["clean_text"] = df["clean_text"].astype(str)

# Strip whitespace
df["clean_text"] = df["clean_text"].str.strip()

# Remove empty strings
df = df[df["clean_text"] != ""]

# Remove literal "nan" strings (extra safety)
df = df[df["clean_text"].str.lower() != "nan"]

X = df["clean_text"]
y = df["label"]

print("Final dataset shape:", df.shape)
print("NaN check in X:", X.isna().sum())

# ===============================
# TF-IDF Vectorization
# ===============================
tfidf = TfidfVectorizer(
    max_features=5000,
    ngram_range=(1, 2),
    stop_words="english"
)

X_tfidf = tfidf.fit_transform(X)

print("TF-IDF feature matrix shape:", X_tfidf.shape)

# ===============================
# Train-Test Split
# ===============================
X_train, X_test, y_train, y_test = train_test_split(
    X_tfidf,
    y,
    test_size=0.2,
    random_state=42,
    stratify=y
)

print("Training samples:", X_train.shape[0])
print("Testing samples:", X_test.shape[0])

# ===============================
# Save vectorizer & split data
# ===============================
MODELS_DIR = BASE_DIR / "models"
MODELS_DIR.mkdir(exist_ok=True)

joblib.dump(tfidf, MODELS_DIR / "tfidf_vectorizer.pkl")
joblib.dump(X_train, MODELS_DIR / "X_train.pkl")
joblib.dump(X_test, MODELS_DIR / "X_test.pkl")
joblib.dump(y_train, MODELS_DIR / "y_train.pkl")
joblib.dump(y_test, MODELS_DIR / "y_test.pkl")

print("TF-IDF vectorizer and datasets saved successfully!")
