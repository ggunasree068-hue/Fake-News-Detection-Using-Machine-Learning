import joblib
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import confusion_matrix, classification_report

# ===============================
# Load model and test data
# ===============================
model = joblib.load("models/fake_news_model.pkl")
X_test = joblib.load("models/X_test.pkl")
y_test = joblib.load("models/y_test.pkl")

# ===============================
# Predictions
# ===============================
y_pred = model.predict(X_test)

# ===============================
# Classification Report
# ===============================
print("\nClassification Report:")
print(classification_report(y_test, y_pred))

# ===============================
# Confusion Matrix
# ===============================
cm = confusion_matrix(y_test, y_pred)

plt.figure(figsize=(6, 5))
sns.heatmap(
    cm,
    annot=True,
    fmt="d",
    cmap="Blues",
    xticklabels=["Real", "Fake"],
    yticklabels=["Real", "Fake"]
)
plt.xlabel("Predicted Label")
plt.ylabel("Actual Label")
plt.title("Confusion Matrix - Fake News Detection")
plt.show()
