import pandas as pd
import re
import nltk
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer

# Download NLP resources (run once)
nltk.download('stopwords')
nltk.download('wordnet')

DATA_PATH = "data/raw/WELFake_Dataset.csv"
OUTPUT_PATH = "data/processed/cleaned_data.csv"

# Load dataset
df = pd.read_csv(DATA_PATH)

# Drop rows with missing text
df.dropna(subset=['title', 'text'], inplace=True)

# Combine title and text
df['content'] = df['title'] + " " + df['text']

# Initialize NLP tools
stop_words = set(stopwords.words('english'))
lemmatizer = WordNetLemmatizer()

def clean_text(text):
    text = text.lower()
    text = re.sub(r"http\S+", "", text)          # Remove URLs
    text = re.sub(r"[^a-z\s]", "", text)         # Remove punctuation & numbers
    words = text.split()
    words = [lemmatizer.lemmatize(word) for word in words if word not in stop_words]
    return " ".join(words)

# Apply cleaning
df['clean_text'] = df['content'].apply(clean_text)

# Save processed data
df[['clean_text', 'label']].to_csv(OUTPUT_PATH, index=False)

print("Preprocessing completed successfully!")
print("Saved cleaned data to:", OUTPUT_PATH)
print("Final dataset shape:", df[['clean_text', 'label']].shape)
